<?php echo $__env->make('Chatify::layouts.headLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<meta name="user-role" content="<?php echo e(Auth::user()->role); ?>">
<div class="messenger">
    
    <div class="messenger-listView <?php echo e(!!$id ? 'conversation-active' : ''); ?>">
        
        <div class="m-header">
            <nav class="chatify-header-nav">
                <a href="<?php echo e(Auth::user()->role === 'dokter' ? '/nakes/dashboard' : '/konsultasi'); ?>" class="chatify-header-link">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo Klinik" class="chatify-logo">
                    <div class="chatify-title-wrapper">
                        <span class="chatify-title-main">Klinik Pratama</span>
                        <span class="chatify-title-sub">Dokter Yanti</span>
                    </div>
                </a>
                
                <div class="m-header-right">
                    <a href="<?php echo e(Auth::user()->role === 'dokter' ? '/nakes/dashboard' : '/konsultasi'); ?>" title="Kembali ke <?php echo e(Auth::user()->role === 'dokter' ? 'Dashboard Dokter' : 'Halaman Konsultasi'); ?>">
                        <i class="fas fa-home"></i>
                    </a>
                    <a href="#" class="listView-x"><i class="fas fa-times"></i></a>
                </div>
            </nav>
            
            <input type="text" class="messenger-search" placeholder="Cari pesan atau pengguna..." />
            
            
        </div>
        
        <div class="m-body contacts-container">
           
           
           <div class="show messenger-tab users-tab app-scroll" data-view="users">
               
               <div class="favorites-section">
                <p class="messenger-title"><span>Favorites</span></p>
                <div class="messenger-favorites app-scroll-hidden"></div>
               </div>
               
               <div class="listOfContacts" style="width: 100%;height: calc(100% - 200px);position: relative;"></div>
           </div>
             
           <div class="messenger-tab search-tab app-scroll" data-view="search">
                
                <p class="messenger-title"><span>Pencarian</span></p>
                <div class="search-records">
                    <p class="message-hint center-el"><span>Ketik untuk mencari...</span></p>
                </div>
             </div>
        </div>
    </div>

    
    <div class="messenger-messagingView">
        
        <div class="m-header m-header-messaging">
            <nav class="chatify-d-flex chatify-justify-content-between chatify-align-items-center">
                
                <div class="header-left-section">
                    <a href="#" class="back-btn show-listView"><i class="fas fa-arrow-left"></i></a>
                    <div class="avatar av-s header-avatar show-infoSide" style="cursor: pointer;" title="Lihat detail pengguna">
                    </div>
                    <a href="#" class="user-name show-infoSide" title="Lihat detail pengguna"><?php echo e(config('chatify.name')); ?></a>
                </div>
                
            </nav>
            
            <div class="internet-connection">
                <span class="ic-connected">Terhubung</span>
                <span class="ic-connecting">Menghubungkan...</span>
                <span class="ic-noInternet">Tidak ada koneksi internet</span>
            </div>
        </div>

        
        <div class="m-body messages-container app-scroll">
            <div class="messages">
                <p class="message-hint center-el"><span>Pilih percakapan untuk mulai mengirim pesan</span></p>
            </div>
            
            <div class="typing-indicator">
                <div class="message-card typing">
                    <div class="message">
                        <span class="typing-dots">
                            <span class="dot dot-1"></span>
                            <span class="dot dot-2"></span>
                            <span class="dot dot-3"></span>
                        </span>
                    </div>
                </div>
            </div>

        </div>
        
        <?php echo $__env->make('Chatify::layouts.sendForm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    
    <div class="messenger-infoView app-scroll">
        
        <nav>
            <p>Detail Pengguna</p>
            <a href="#"><i class="fas fa-times"></i></a>
        </nav>
        <?php echo view('Chatify::layouts.info')->render(); ?>

    </div>
</div>

<?php echo $__env->make('Chatify::layouts.modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php if(Auth::user()->role === 'pasien'): ?>
    <?php echo $__env->make('components.payment-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php echo $__env->make('Chatify::layouts.footerLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<meta name="user-role" content="<?php echo e(Auth::user()->role); ?>">


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php /**PATH E:\ProjekKlinik\resources\views/vendor/Chatify/pages/app.blade.php ENDPATH**/ ?>