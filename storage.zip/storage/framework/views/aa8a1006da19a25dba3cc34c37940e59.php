<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Klinik Dokter Yanti</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <div class="login-card">
            <div class="login-image">
                <img src="<?php echo e(asset('img/ilustrasi2.png')); ?>" alt="Doctor Illustration">
            </div>
            <div class="login-form">
                <div class="form-header">
                    <h2>Reset Password</h2>
                    <p>Masukkan email Anda untuk reset password</p>
                </div>

                <div class="reset-info">
                    <div class="info-box">
                        <i class="fa-solid fa-circle-info"></i>
                        <p>Kami akan mengirimkan kode OTP reset password ke email Anda. Silakan periksa email anda.</p>
                    </div>
                </div>

                <form action="/reset-password" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <?php if($errors->any()): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Gagal',
                                        text: '<?php echo e($error); ?>',
                                        confirmButtonText: 'OK'
                                    });
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil',
                                    text: '<?php echo e(session('status')); ?>',
                                    confirmButtonText: 'OK'
                                });
                            });
                        </script>
                    <?php endif; ?>

                    <div class="form-group">
                        <button type="submit" class="btn-login">
                            Kirim Link Reset Password
                        </button>
                    </div>

                    <div class="signin">                            
                        <p><a href="/login">Kembali ke Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
</body>
</html><?php /**PATH E:\ProjekKlinik\resources\views/auth/resetpw.blade.php ENDPATH**/ ?>