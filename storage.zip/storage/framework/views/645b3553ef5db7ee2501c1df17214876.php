

<?php $__env->startSection('content'); ?>
<div class="obat-container" style="margin-top: 100px;">
  <!-- Judul & Breadcrumb -->
  <div class="obat-detail-header1">
    <h1 class="page-title1">Obat & Vitamin Kesehatan</h1>
    <nav class="breadcrumb1">
      <a href="<?php echo e(route('obat.index')); ?>">Dashboard</a> >
      <span>Lihat Semua Obat</span>
    </nav>
  </div>

  <!-- Search + Filter -->
  <div class="obat-search-filter">
    <form action="<?php echo e(route('obat.all')); ?>" method="GET" class="obat-search-form">
      <input type="text" name="q" placeholder="Cari obat atau suplemen..." value="<?php echo e(request('q')); ?>">
      <button type="submit">Cari</button>
    </form>

    <div class="obat-category-filter">
      <a href="<?php echo e(route('obat.all')); ?>" class="<?php echo e(request('kategori')=='' ? 'active' : ''); ?>">Semua</a>
      <a href="<?php echo e(route('obat.all', ['kategori'=>'Obat Bebas'])); ?>" class="<?php echo e(request('kategori')=='Obat Bebas' ? 'active' : ''); ?>">Obat Bebas</a>
      <a href="<?php echo e(route('obat.all', ['kategori'=>'Obat Bebas Terbatas'])); ?>" class="<?php echo e(request('kategori')=='Obat Bebas Terbatas' ? 'active' : ''); ?>">Obat Bebas Terbatas</a>
      <a href="<?php echo e(route('obat.all', ['kategori'=>'Obat Keras'])); ?>" class="<?php echo e(request('kategori')=='Obat Keras' ? 'active' : ''); ?>">Obat Keras</a>
      <a href="<?php echo e(route('obat.all', ['kategori'=>'Jamu'])); ?>" class="<?php echo e(request('kategori')=='Jamu' ? 'active' : ''); ?>">Jamu</a>
    </div>
  </div>

  <!-- Grid Produk -->
  <div class="obat-grid">
    <?php $__empty_1 = true; $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="obat-card">
        <img src="<?php echo e(asset('storage/'.$item->foto)); ?>" alt="<?php echo e($item->nama_obat); ?>">
        <h3><?php echo e($item->nama_obat); ?></h3>
        <p class="obat-unit"><?php echo e($item->bentuk); ?></p>
        <a href="<?php echo e(route('obat.show', $item->id)); ?>">
          <button class="obat-btn">Lihat Informasi Obat</button>
        </a>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="obat-empty">Tidak ada obat ditemukan</p>
    <?php endif; ?>
  </div>

  <!-- Pagination -->
  <div class="obat-pagination">
    <?php echo e($obat->withQueryString()->links()); ?>

  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/obat/Obat_all.blade.php ENDPATH**/ ?>