
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
    <h1>Data Pasien</h1>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4>Data Pasien Yang Terdaftar Sistem (<?php echo e($pasiens->total()); ?> pasien)</h4>

          <div class="card-header-form d-flex align-items-center">
              <form class="me-2" method="GET">
                <div class="input-group">
                  <input type="text" name="search" class="form-control" placeholder="Cari nama atau email..." value="<?php echo e(request('search')); ?>">
                  <div class="input-group-btn">
                    <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                  </div>
                </div>
              </form>

              <div class="dropdown" style="margin-left: 10px;">
                <button class="btn btn-light" type="button" id="filter-btn" data-toggle="dropdown" data-display="static">
                  <i class="fa-solid fa-filter" style="color:#6777ef;"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right p-2">
                  <form method="GET">
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                    <label class="mb-1">Filter Status</label>
                    <select name="status" class="form-control form-control-sm" onchange="this.form.submit()">
                      <option value="">Semua Status</option>
                      <option value="reguler" <?php echo e(request('status') == 'reguler' ? 'selected' : ''); ?>>Reguler</option>
                      <option value="langganan" <?php echo e(request('status') == 'langganan' ? 'selected' : ''); ?>>Langganan</option>
                    </select>
                  </form>
                  <?php if(request('status') || request('search')): ?>
                  <hr class="my-2">
                  <button type="button" class="btn btn-sm btn-secondary w-100" onclick="clearFilters()">
                    <i class="fas fa-times"></i> Clear Filter
                  </button>
                  <?php endif; ?>
                </div>
              </div>
          </div>
        </div>

        <div class="card-body p-0">
          <div class="table-responsive tenaga-table-wrapper">
            <table class="table table-striped tenaga-table">
              <thead>
                <tr>
                  <th style="width: 50px;">No</th>
                  <th>Nama</th>
                  <th style="min-width: 150px;">Email</th>   
                  <th style="min-width: 100px;">Status</th>
                  <th style="min-width: 150px;">Periode Langganan</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php
                    $hasActiveSubscription = $pasien->subscriptions->isNotEmpty();
                    $activeSubscription = $hasActiveSubscription ? $pasien->subscriptions->first() : null;
                  ?>
                  <tr>
                    <td><?php echo e(($pasiens->currentPage() - 1) * $pasiens->perPage() + $index + 1); ?></td>
                    <td><?php echo e($pasien->name); ?></td>
                    <td><?php echo e($pasien->email); ?></td>
                    <td>
                      <?php if($hasActiveSubscription): ?>
                        <span class="badge badge-primary">Langganan</span>
                      <?php else: ?>
                        <span class="badge badge-success">Reguler</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($hasActiveSubscription && $activeSubscription): ?>
                        <?php echo e($activeSubscription->expires_at->format('d-m-Y')); ?>

                      <?php else: ?>
                        -
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="5" class="text-center">Tidak ada data pasien</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>      

        <?php if($pasiens->hasPages()): ?>
        <div class="card-footer text-right">
          <nav class="d-inline-block">
            <?php echo e($pasiens->appends(request()->query())->links()); ?>

          </nav>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Clear filter functionality
function clearFilters() {
    window.location.href = "<?php echo e(route('data.pasien')); ?>";
}

// Auto submit search on enter
document.querySelector('input[name="search"]').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        this.form.submit();
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/adminDatapasien/DataPasien.blade.php ENDPATH**/ ?>