<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Klinik Dokter Yanti</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <div class="login-card">
            <div class="login-image">
                <img src="<?php echo e(asset('img/ilustrasi2.png')); ?>" alt="Doctor Illustration">
            </div>
            <div class="login-form">
                <div class="form-header">
                    <h2>Klinik Pratama Dokter Yanti</h2>
                    <p>Murah, Nyaman, Sehat</p>
                </div>
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="" required autocomplete="email" autofocus placeholder="Email">
                            <span class="invalid-feedback" role="alert">
                                <strong></strong>
                            </span>
                    </div>

                    <div class="form-group">
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                        <span class="password-toggle" onclick="togglePassword()">
                            <i class="fa-solid fa-eye-slash" id="toggleIcon"></i>
                        </span>
                            <span class="invalid-feedback" role="alert">
                                <strong></strong>
                            </span>
                    </div>
                    <?php if($errors->any()): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Gagal Login',
                                        text: '<?php echo e($error); ?>',
                                        confirmButtonText: 'Coba Lagi'
                                    });
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil',
                                    text: '<?php echo e(session('status')); ?>',
                                    confirmButtonText: 'OK'
                                });
                            });
                        </script>
                    <?php endif; ?>

                    <div class="form-group remember-forgot">
                        <div class="remember-me">
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label for="remember">Ingat Saya?</label>
                        </div>
                        <a class="forgot-password" href="/reset-password">
                            Lupa Password?
                        </a>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn-login">
                            Masuk
                        </button>
                    </div>

                    <div class="signin">                            
                        <p><a href="/registrasi">belum punya akun?</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
</body>
</html><?php /**PATH E:\ProjekKlinik\resources\views/auth/login.blade.php ENDPATH**/ ?>