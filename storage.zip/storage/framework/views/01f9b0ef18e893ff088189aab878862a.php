
<?php $__env->startSection('content'); ?>
<section class="section">  
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4>Data Janji Berobat Pasien</h4>
          
        </div>
        <div class="card-body p-0">
          <!-- hanya satu table-responsive -->
          <div class="table-responsive tenaga-table-wrapper">
            <table class="table table-striped tenaga-table">
              <thead>
                <tr>
                  <th style="width: 50px;">No</th>
                  <th class="sort-nama" style="cursor: pointer;">Nama <i class="fas fa-sort"></i></th>
                  <th style="min-width: 80px;">Tanggal Janji</th>
                  <th>Jam</th>
                  <th style="min-width: 180px;">Keluhan</th>                  
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key + 1); ?></td>
                  <td><?php echo e($a->nama); ?></td>                  
                  <td style="min-width: 80px;"><?php echo e($a->tanggal); ?></td>
                  <td style="min-width: 50px;"><?php echo e(substr($a->jam, 0, 5)); ?></td>
                  <td class="desc-col"><?php echo e($a->keluhan); ?></td>
                  <td>
                    <span class="badge 
                      <?php if($a->status == 'Disetujui'): ?> badge-success 
                      <?php elseif($a->status == 'Menunggu'): ?> badge-secondary 
                      <?php elseif($a->status == 'Dibatalkan'): ?> badge-danger 
                      <?php else: ?> badge-info <?php endif; ?>">
                      <?php echo e($a->status); ?>

                    </span>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>      

        <div class="card-footer text-right">
          <nav class="d-inline-block">
            <ul class="pagination mb-0">
              <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1"><i class="fas fa-chevron-left"></i></a>
              </li>
              <li class="page-item active">
                <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
              </li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item">
                <a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
          
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dokter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/dokter/JanjiTemuDokter.blade.php ENDPATH**/ ?>