

<?php $__env->startSection('content'); ?>
<section class="hero-services">
  <div class="hero-overlay">
    <div class="hero-text">
      <h1>Janji Berobat</h1>
      <p>Atur janji temu dengan dokter dengan mudah, cepat, dan tanpa antri lama.</p>
    </div>
  </div>
</section>

<div class="appointment-wrapper">
  <div class="appointment-info">
    <h2>Tentang Layanan Janji Berobat</h2>
    <p>Kami membantu Anda mendapatkan waktu konsultasi yang sesuai dengan dokter terbaik kami.</p>

    <div class="appointment-features">
      <div class="feature-item">
        <div class="icon icon-blue"><i class="fa-solid fa-clock"></i></div>
        <div><h4>Hemat Waktu</h4><p>Kurangi waktu tunggu dengan jadwal yang pasti.</p></div>
      </div>
      <div class="feature-item">
        <div class="icon icon-green"><i class="fa-solid fa-user-doctor"></i></div>
        <div><h4>Dokter Terbaik</h4><p>Konsultasi dengan tenaga medis berpengalaman.</p></div>
      </div>
      <div class="feature-item">
        <div class="icon icon-yellow"><i class="fa-solid fa-mobile-screen-button"></i></div>
        <div><h4>Mudah Digunakan</h4><p>Proses pembuatan janji cepat dan praktis.</p></div>
      </div>
    </div>
  </div>

  <div class="appointment-status-side">
    <h2>Status Janji Anda</h2>

    <div class="appointment-status empty">
      <div class="status-icon">📅</div>
      <h3>Belum Ada Janji</h3>
      <p>Yuk, buat janji berobat pertama Anda sekarang!</p>

      <?php if(auth()->guard()->check()): ?>
        <a href="javascript:void(0)" class="btn btn-primary" id="btnTambah">+ Buat Janji</a>
      <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">+ Buat Janji</a>
      <?php endif; ?>
    </div>

    <div class="appointment-list" style="display: none;"></div>
  </div>
</div>

<?php echo $__env->make('layanan._modalFormAppoint', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(auth()->guard()->check()): ?>
  <script src="<?php echo e(asset('js/data_janji.js')); ?>"></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app4', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/layanan/appointment.blade.php ENDPATH**/ ?>