KLINIK ONLINE - RESET PASSWORD
================================

Halo <?php echo e($user->name ?? 'Pengguna'); ?>,

Anda telah meminta untuk mereset password akun Anda.

KODE OTP ANDA: <?php echo e($otp); ?>


Kode ini berlaku selama 15 menit.

PENTING:
- Jangan bagikan kode OTP ini kepada siapa pun
- Jika Anda tidak meminta reset password, abaikan email ini
- Segera hubungi support jika ada aktivitas mencurigakan

Terima kasih,
Tim Klinik Online

---
Email: support@klinikonline.com
Telepon: (021) 1234-5678
Website: www.klinikonline.com

© <?php echo e(date('Y')); ?> Klinik Online. Email otomatis, jangan dibalas.<?php /**PATH E:\ProjekKlinik\resources\views/emails/reset-password-text.blade.php ENDPATH**/ ?>