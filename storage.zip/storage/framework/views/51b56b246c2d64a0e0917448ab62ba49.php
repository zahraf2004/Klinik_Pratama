

<?php $__env->startSection('content'); ?>
<div class="obat-detail-container">

  <!-- Judul & Breadcrumb -->
  <div class="obat-detail-header" >
    <h1 class="page-title" >Obat & Vitamin Kesehatan</h1>
    <nav class="breadcrumb">
      <a href="<?php echo e(route('obat.index')); ?>">Dashboard</a> >
      <a href="<?php echo e(route('obat.all')); ?>">Lihat Semua Obat</a> >
      <span>Detail Obat</span>
    </nav>
  </div>

  <!-- Kiri: Foto Produk -->
  <div class="obat-detail-left">
    <img src="<?php echo e(asset('storage/'.$obat->foto)); ?>" alt="<?php echo e($obat->nama_obat); ?>">
  </div>

  <!-- Tengah: Informasi Produk -->
  <div class="obat-detail-middle">
    <h1 class="obat-title"><?php echo e($obat->nama_obat); ?></h1>

    <!-- Badge Kategori dengan logo -->
    <?php
        $kategori = strtolower($obat->kategori);
        $img = 'default.png'; 

        switch ($kategori) {
            case 'obat bebas': $img = 'bebas.png'; break;
            case 'obat bebas terbatas': $img = 'bebas_terbatas.png'; break;
            case 'obat herbal': $img = 'herbal.png'; break;
            case 'jamu': $img = 'Jamu.png'; break;
            case 'fitofarmaka': $img = 'Fitofarmaka.png'; break;
            case 'obat keras': $img = 'Keras.png'; break;
            case 'narkotika': $img = 'Narkotika.png'; break;
        }
    ?>

    <div class="kategori-badge">
      <img src="<?php echo e(asset('img/'.$img)); ?>" alt="<?php echo e($obat->kategori); ?>">
      <span><?php echo e($obat->kategori); ?></span>
    </div>

    <p class="bentuk">Bentuk: <?php echo e($obat->bentuk); ?></p>
    <p class="bentuk">Klasifikasi: <?php echo e($obat->klasifikasi); ?></p>

    <div class="deskripsi-box">
      <h3>Deskripsi & Manfaat</h3>
      <p><?php echo e($obat->deskripsi); ?></p>
    </div>

    <div class="dosis-box">
      <h3>Dosis & Aturan Pakai</h3>
      <p><?php echo e($obat->dosis ?? 'Ikuti aturan pakai sesuai petunjuk dokter.'); ?></p>
    </div>
  </div>

  <!-- Kanan: Rekomendasi Produk -->
  <div class="obat-detail-right">
    <h3 style="font-weight:bold;">Rekomendasi Produk Lain</h3>
    <div class="rekomendasi-list">
      <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rekomendasi-card">
          <img src="<?php echo e(asset('storage/'.$item->foto)); ?>" alt="<?php echo e($item->nama_obat); ?>">
          <p><?php echo e($item->nama_obat); ?></p>
          <p class="unit"><?php echo e($item->bentuk); ?></p>
          <a href="<?php echo e(route('obat.show', $item->id)); ?>" class="btn-rekomendasi">Lihat Obat</a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app4', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/obat/detailObat.blade.php ENDPATH**/ ?>