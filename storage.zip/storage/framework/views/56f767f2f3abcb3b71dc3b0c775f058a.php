<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi OTP - Klinik Dokter Yanti</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/otp.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <div class="login-card">
            <div class="login-image">
                <img src="<?php echo e(asset('img/ilustrasi2.png')); ?>" alt="Doctor Illustration">
            </div>
            <div class="login-form">

                <div class="reset-info">
                    <div class="info-box">
                        <i class="fa-solid fa-envelope"></i>
                        <p>Kode OTP telah dikirim ke <strong><?php echo e(session('reset_email', 'email@example.com')); ?></strong></p>
                    </div>
                </div>

                <form action="/verify-otp" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e(session('reset_email')); ?>">
                    
                    <div class="form-group">
                        <label for="otp" class="form-label">Kode OTP</label>
                        <input id="otp" type="text" class="form-control <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otp" value="<?php echo e(old('otp')); ?>" required maxlength="6" placeholder="Masukkan 6 digit kode OTP">
                        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label">Password Baru</label>
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required placeholder="Masukkan password baru">
                        <span class="password-toggle" onclick="togglePassword('password','toggleIcon1')">
                            <i class="fa-solid fa-eye-slash" id="toggleIcon1"></i>
                        </span>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="password_confirmation" class="form-label">Konfirmasi Password Baru</label>
                        <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required placeholder="Ketik ulang password baru">
                        <span class="password-toggle" onclick="togglePassword('password_confirmation','toggleIcon2')">
                            <i class="fa-solid fa-eye-slash" id="toggleIcon2"></i>
                        </span>
                    </div>

                    <?php if($errors->any()): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Gagal',
                                        text: '<?php echo e($error); ?>',
                                        confirmButtonText: 'OK'
                                    });
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: '<?php echo e(session('error')); ?>',
                                    confirmButtonText: 'OK'
                                });
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    icon: 'info',
                                    title: 'Informasi',
                                    text: '<?php echo e(session('status')); ?>',
                                    confirmButtonText: 'OK'
                                });
                            });
                        </script>
                    <?php endif; ?>

                    <div class="form-group">
                        <button type="submit" class="btn-login">
                            Reset Password
                        </button>
                    </div>

                    <div class="otp-resend">
                        <p>Tidak menerima kode OTP?</p>
                        <form action="/resend-otp" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="email" value="<?php echo e(session('reset_email')); ?>">
                            <button type="submit" class="resend-link" style="background: none; border: none; color: #007bff; text-decoration: underline; cursor: pointer;">Kirim Ulang Kode</button>
                        </form>
                    </div>

                    <div class="signin">                            
                        <p><a href="/login">Kembali ke Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
    <script>
        // Auto focus on OTP input
        document.getElementById('otp').focus();
        
        // Only allow numbers in OTP field
        document.getElementById('otp').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html>
<?php /**PATH E:\ProjekKlinik\resources\views/auth/otpreset.blade.php ENDPATH**/ ?>