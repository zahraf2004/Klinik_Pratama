<!-- Review Carousel Component -->
<section class="review-carousel-section">
    <div class="review-carousel-container">
        <h2 class="review-section-title">Ulasan Dari Pasien Kami</h2>
        <p class="review-section-subtitle">Cerita nyata dari pasien yang mempercayakan kesehatannya kepada kami.</p>
        
        <div class="review-carousel-wrapper">
            <div class="review-carousel" id="reviewCarousel">
                <!-- Reviews akan dimuat via JavaScript -->
                <div class="review-loading">
                    <div class="loading-spinner"></div>
                    <p>Memuat ulasan...</p>
                </div>
            </div>
            
            <!-- Navigation Arrows -->
            <button class="carousel-nav prev" id="prevBtn" onclick="moveCarousel(-1)">
                <i class="fas fa-chevron-left"></i>
            </button>
            <button class="carousel-nav next" id="nextBtn" onclick="moveCarousel(1)">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
        
        <!-- Dots Indicator -->
        <div class="carousel-dots" id="carouselDots">
            <!-- Dots akan dibuat via JavaScript -->
        </div>
    </div>
</section>

<style>
/* Review Carousel Styles */
.review-carousel-section {
    padding: 80px 0;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    font-family: "Nunito", sans-serif;
}

.review-carousel-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.review-section-title {
    text-align: center;
    font-size: 36px;
    font-weight: 700;
    color: #333;
    margin-bottom: 15px;
}

.review-section-subtitle {
    text-align: center;
    font-size: 18px;
    color: #666;
    margin-bottom: 50px;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.review-carousel-wrapper {
    position: relative;
    overflow: hidden;
    border-radius: 20px;
    background: white;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
    padding: 40px 20px;
}

.review-carousel {
    display: flex;
    transition: transform 0.5s ease-in-out;
    gap: 30px;
}

.review-card {
    min-width: 350px;
    flex-shrink: 0;
    background: white;
    border-radius: 15px;
    padding: 30px 25px;
    text-align: center;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
    border: 1px solid #f0f0f0;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.review-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
}

/* Rating Stars */
.review-rating {
    margin-bottom: 20px;
}

.review-stars {
    display: flex;
    justify-content: center;
    gap: 3px;
    margin-bottom: 5px;
}

.review-star {
    font-size: 24px;
    color: #ffc107;
    text-shadow: 0 1px 3px rgba(255, 193, 7, 0.3);
}

.review-star.empty {
    color: #e0e0e0;
}

.rating-number {
    font-size: 14px;
    color: #666;
    font-weight: 600;
}

/* Review Content */
.review-content {
    margin-bottom: 25px;
}

.review-text {
    font-size: 16px;
    line-height: 1.6;
    color: #555;
    font-style: italic;
    margin-bottom: 0;
    position: relative;
}

.review-text::before {
    content: '"';
    font-size: 40px;
    color: #0069ab;
    position: absolute;
    top: -10px;
    left: -15px;
    font-family: serif;
}

.review-text::after {
    content: '"';
    font-size: 40px;
    color: #0069ab;
    position: absolute;
    bottom: -25px;
    right: -15px;
    font-family: serif;
}

/* Reviewer Info */
.reviewer-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.reviewer-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0069ab, #004d7a);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 5px;
    box-shadow: 0 4px 15px rgba(0, 105, 171, 0.3);
}

.reviewer-name {
    font-size: 18px;
    font-weight: 700;
    color: #333;
    margin: 0;
}

.review-date {
    font-size: 14px;
    color: #999;
    margin: 0;
}

/* Navigation Arrows */
.carousel-nav {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: white;
    border: 2px solid #0069ab;
    color: #0069ab;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 18px;
    z-index: 10;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.carousel-nav:hover {
    background: #0069ab;
    color: white;
    transform: translateY(-50%) scale(1.1);
    box-shadow: 0 6px 20px rgba(0, 105, 171, 0.3);
}

.carousel-nav.prev {
    left: -25px;
}

.carousel-nav.next {
    right: -25px;
}

.carousel-nav:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: translateY(-50%) scale(1);
}

/* Dots Indicator */
.carousel-dots {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 30px;
}

.carousel-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #ddd;
    cursor: pointer;
    transition: all 0.3s ease;
}

.carousel-dot.active {
    background: #0069ab;
    transform: scale(1.2);
}

.carousel-dot:hover {
    background: #0069ab;
    opacity: 0.7;
}

/* Loading State */
.review-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 60px 20px;
    color: #666;
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #0069ab;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 15px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Empty State */
.review-empty {
    text-align: center;
    padding: 60px 20px;
    color: #666;
}

.review-empty i {
    font-size: 60px;
    color: #ddd;
    margin-bottom: 20px;
}

.review-empty h3 {
    font-size: 24px;
    color: #333;
    margin-bottom: 10px;
}

.review-empty p {
    font-size: 16px;
    color: #666;
}

/* Responsive Design */
@media (max-width: 992px) {
    .review-card {
        min-width: calc(50% - 15px);
    }
}

@media (max-width: 768px) {
    .review-carousel-section {
        padding: 60px 0;
    }
    
    .review-section-title {
        font-size: 28px;
    }
    
    .review-section-subtitle {
        font-size: 16px;
        margin-bottom: 40px;
    }
    
    .review-carousel-wrapper {
        padding: 30px 15px;
    }
    
    .review-card {
        min-width: calc(100% - 30px);
        padding: 25px 20px;
    }
    
    .review-text {
        font-size: 15px;
    }
    
    .reviewer-name {
        font-size: 16px;
    }
    
    .carousel-nav {
        width: 40px;
        height: 40px;
        font-size: 16px;
    }
    
    .carousel-nav.prev {
        left: -20px;
    }
    
    .carousel-nav.next {
        right: -20px;
    }
}

@media (max-width: 480px) {
    .review-card {
        min-width: 250px;
        padding: 20px 15px;
    }
    
    .review-text::before,
    .review-text::after {
        font-size: 30px;
    }
    
    .reviewer-avatar {
        width: 50px;
        height: 50px;
        font-size: 20px;
    }
}
</style>

<script>
// Review Carousel JavaScript
let currentSlide = 0;
let reviews = [];
let autoSlideInterval;

document.addEventListener('DOMContentLoaded', function() {
    loadReviews();
});

async function loadReviews() {
    try {
        const response = await fetch('/api/reviews/homepage');
        const data = await response.json();
        
        if (data.success && data.reviews.length > 0) {
            reviews = data.reviews;
            renderReviews();
            initializeCarousel();
            startAutoSlide();
        } else {
            showEmptyState();
        }
    } catch (error) {
        console.error('Error loading reviews:', error);
        showEmptyState();
    }
}

function renderReviews() {
    const carousel = document.getElementById('reviewCarousel');
    
    const reviewsHTML = reviews.map(review => `
        <div class="review-card">
            <div class="review-rating">
                <div class="review-stars">
                    ${generateStars(review.rating)}
                </div>
                <div class="rating-number">${review.rating}/5</div>
            </div>
            
            <div class="review-content">
                <p class="review-text">${review.review_content}</p>
            </div>
            
            <div class="reviewer-info">
                <div class="reviewer-avatar">
                    ${review.reviewer_name.charAt(0).toUpperCase()}
                </div>
                <h4 class="reviewer-name">${review.reviewer_name}</h4>
                <p class="review-date">${formatDate(review.created_at)}</p>
            </div>
        </div>
    `).join('');
    
    carousel.innerHTML = reviewsHTML;
}

function generateStars(rating) {
    let starsHTML = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            starsHTML += '<span class="review-star">★</span>';
        } else {
            starsHTML += '<span class="review-star empty">★</span>';
        }
    }
    return starsHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
        return 'Kemarin';
    } else if (diffDays < 7) {
        return `${diffDays} hari yang lalu`;
    } else if (diffDays < 30) {
        const weeks = Math.floor(diffDays / 7);
        return `${weeks} minggu yang lalu`;
    } else {
        const months = Math.floor(diffDays / 30);
        return `${months} bulan yang lalu`;
    }
}

function initializeCarousel() {
    createDots();
    updateCarousel();
    updateNavigation();
}

function createDots() {
    const dotsContainer = document.getElementById('carouselDots');
    const visibleSlides = getVisibleSlides();
    const totalDots = Math.ceil(reviews.length / visibleSlides);
    
    let dotsHTML = '';
    for (let i = 0; i < totalDots; i++) {
        dotsHTML += `<span class="carousel-dot ${i === 0 ? 'active' : ''}" onclick="goToSlide(${i})"></span>`;
    }
    
    dotsContainer.innerHTML = dotsHTML;
}

function getVisibleSlides() {
    const width = window.innerWidth;
    if (width < 576) return 1;
    if (width < 992) return 2;
    return 3;
}

function moveCarousel(direction) {
    const visibleSlides = getVisibleSlides();
    const maxSlide = Math.ceil(reviews.length / visibleSlides) - 1;
    
    currentSlide += direction;
    
    if (currentSlide < 0) {
        currentSlide = maxSlide;
    } else if (currentSlide > maxSlide) {
        currentSlide = 0;
    }
    
    updateCarousel();
    updateNavigation();
    updateDots();
    resetAutoSlide();
}

function goToSlide(slideIndex) {
    currentSlide = slideIndex;
    updateCarousel();
    updateNavigation();
    updateDots();
    resetAutoSlide();
}

function updateCarousel() {
    const carousel = document.getElementById('reviewCarousel');
    const visibleSlides = getVisibleSlides();
    const slideWidth = 100 / visibleSlides;
    const translateX = -(currentSlide * slideWidth);
    
    carousel.style.transform = `translateX(${translateX}%)`;
}

function updateNavigation() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const visibleSlides = getVisibleSlides();
    const maxSlide = Math.ceil(reviews.length / visibleSlides) - 1;
    
    prevBtn.disabled = false;
    nextBtn.disabled = false;
    
    if (reviews.length <= visibleSlides) {
        prevBtn.style.display = 'none';
        nextBtn.style.display = 'none';
    } else {
        prevBtn.style.display = 'flex';
        nextBtn.style.display = 'flex';
    }
}

function updateDots() {
    const dots = document.querySelectorAll('.carousel-dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });
}

function startAutoSlide() {
    if (reviews.length > getVisibleSlides()) {
        autoSlideInterval = setInterval(() => {
            moveCarousel(1);
        }, 5000);
    }
}

function resetAutoSlide() {
    clearInterval(autoSlideInterval);
    startAutoSlide();
}

function showEmptyState() {
    const carousel = document.getElementById('reviewCarousel');
    carousel.innerHTML = `
        <div class="review-empty">
            <i class="fas fa-comments"></i>
            <h3>Belum Ada Review</h3>
            <p>Jadilah yang pertama memberikan review untuk layanan kami!</p>
        </div>
    `;
    
    // Hide navigation
    document.getElementById('prevBtn').style.display = 'none';
    document.getElementById('nextBtn').style.display = 'none';
    document.getElementById('carouselDots').style.display = 'none';
}

// Handle window resize
window.addEventListener('resize', function() {
    if (reviews.length > 0) {
        initializeCarousel();
    }
});
</script><?php /**PATH E:\ProjekKlinik\resources\views/components/review-carousel.blade.php ENDPATH**/ ?>