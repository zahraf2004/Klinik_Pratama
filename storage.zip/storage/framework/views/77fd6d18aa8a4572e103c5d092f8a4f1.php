

<?php $__env->startSection('title', 'Paket Berlangganan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <!-- Header -->
            <div class="text-center mb-5">
                <h2 class="mb-3">Pilih Paket Berlangganan</h2>
                <p class="lead text-muted">Chat unlimited dengan dokter profesional kapan saja</p>
            </div>

            <!-- Free vs Premium Comparison -->
            <div class="row mb-5">
                <div class="col-md-6">
      
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/subscription/plans.blade.php ENDPATH**/ ?>