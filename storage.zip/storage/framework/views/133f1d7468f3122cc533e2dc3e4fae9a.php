<div class="row">
    <div class="col-lg-8 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
            <h4>Tenaga Kesehatan Terbaru</h4>
            <div class="card-header-action">
                <a href="<?php echo e(url('/admin/data-nakes')); ?>" class="btn btn-primary">Lihat Semua</a>
            </div>
            </div>
            <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                <thead>
                    <tr>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>Profesi</th>
                    <th>Email</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $listNakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nakes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="60">
                        <img src="<?php echo e($nakes->foto_path ? asset('storage/'.$nakes->foto_path) : asset('assets/img/avatar/avatar-1.png')); ?>" 
                            alt="Foto <?php echo e($nakes->nama); ?>" 
                            class="rounded-circle" 
                            width="40" height="40">
                        </td>
                        <td>
                        <?php echo e($nakes->nama); ?>

                        </td>
                        <td>
                        <?php echo e($nakes->email); ?>

                        </td>
                        <td>
                        <?php echo e($nakes->role == 'dokter_umum' ? 'Dokter' : ucfirst($nakes->role)); ?>

                        </td>                        
                        <td>
                        <a href="<?php echo e(url('/admin/data-nakes/'.$nakes->id)); ?>" 
                            class="btn btn-info btn-sm btn-action" 
                            data-toggle="tooltip" title="View">
                            <i class="fas fa-eye"></i>
                        </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum ada tenaga kesehatan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>


    <div class="col-lg-4 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
            <h4>Log Aktivitas</h4>
            </div>
            <div class="card-body">
            <ul class="list-unstyled list-unstyled-border mb-0">
                <?php $__empty_1 = true; $__currentLoopData = $logAktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="media">
                <img class="mr-3 rounded-circle" width="50" src="assets/img/avatar/avatar-1.png" alt="avatar">
                <div class="media-body">
                    <div class="float-right text-primary"><?php echo e($log->created_at->diffForHumans()); ?></div>
                    <div class="media-title"><?php echo e($log->user ? $log->user->name : 'Admin'); ?></div>
                    <span class="text-small text-muted"><?php echo $log->description; ?></span>
                </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="media">
                <div class="media-body text-center">
                    <div class="text-muted">Belum ada aktivitas</div>
                </div>
                </li>
                <?php endif; ?>
            </ul>
            </div>
        </div>
        </div>

</div>
<?php /**PATH E:\ProjekKlinik\resources\views/adminDashboard/partials/baris3.blade.php ENDPATH**/ ?>