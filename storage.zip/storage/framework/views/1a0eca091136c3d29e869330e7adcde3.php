<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Klinik Pratama Dokter Yanti</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboardUser.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/obat_all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/telemedicine.css')); ?>">
    <style>
        body, h1, h2, h3, h4, h5, h6, p, a, button {
            font-family: 'Poppins', sans-serif;
        }
    </style>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <div class="app">
        <div class="main-wrapper">
            
            <?php echo $__env->make('partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

             
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->make('partials.Footer2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
    
    <script src="<?php echo e(asset('js/nav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/konsultasi-search.js')); ?>"></script>
</body>
</html><?php /**PATH E:\ProjekKlinik\resources\views/layouts/app3.blade.php ENDPATH**/ ?>