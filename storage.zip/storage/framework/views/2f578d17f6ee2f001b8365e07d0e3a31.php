<section class="doctors" id="doctors">
  <div class="container">
    <h2 class="section-title1">Dokter Kami</h2>
    <p class="section-subtitle2">Tim tenaga profesional yang siap memberikan pelayanan kesehatan terbaik untuk Anda</p>

    <div class="doctor-grid">
      <?php $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="doctor-card">
          <?php if($d->foto_path): ?>
            <img src="<?php echo e(asset('storage/'.$d->foto_path)); ?>" alt="<?php echo e($d->nama); ?>">
          <?php else: ?>
            <img src="<?php echo e(asset('assets/img/avatar/avatar-1.png')); ?>" alt="<?php echo e($d->nama); ?>">
          <?php endif; ?>

          <h3><?php echo e($d->nama); ?></h3>
          <span class="role">
            <?php if($d->role === 'dokter_umum'): ?>
              Dokter Umum
            <?php else: ?>
              Dokter
            <?php endif; ?>
          </span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH E:\ProjekKlinik\resources\views/home/doktor.blade.php ENDPATH**/ ?>