<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Klinik Pratama Dokter Yanti</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

  <!-- CSS Libraries -->

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/modules/fontawesome/css/all.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('css/custom-table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/dokter.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/navbar-fix.css')); ?>">
</head>

<body>
  <div id="app">
    <div class="main-wrapper">

    
      <?php echo $__env->make('partials.navdokter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      
      <?php echo $__env->make('partials.sidebardokter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      
      <div class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>

    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
   <?php if(session('login_success')): ?>
   <script>
     document.addEventListener('DOMContentLoaded', function() {
       Swal.fire({
         icon: 'success',
         title: 'Login Berhasil',
         text: '<?php echo e(session("login_success")); ?>',
         timer: 2000,
         showConfirmButton: false
       });
     });
   </script>
   <?php endif; ?>
   
   <?php if(session('success')): ?>
   <script>
     document.addEventListener('DOMContentLoaded', function() {
       Swal.fire({
         icon: 'success',
         title: 'Berhasil',
         text: '<?php echo e(session("success")); ?>',
         timer: 2000,
         showConfirmButton: false
       });
     });
   </script>
   <?php endif; ?>

  <!-- JS Libraies -->
  <script src="<?php echo e(asset('asset/node_modules/sticky-kit/dist/sticky-kit.min.js')); ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo e(asset('assets/modules/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/page/components-table.js')); ?>"></script>

  <script src="<?php echo e(asset('js/table.js')); ?>"></script>
  <script src="<?php echo e(asset('js/navbar-dropdown.js')); ?>"></script>

</body>
</html>
<?php /**PATH E:\ProjekKlinik\resources\views/layouts/dokter.blade.php ENDPATH**/ ?>