
<?php $__env->startSection('content'); ?>
<div class="konsul-telemedicine">
    <div class="konsul-main-content">

        <!-- Kolom kiri -->
        <div class="konsul-left-column">
            <section class="konsul-section-card">
                <h2 class="konsul-sectiontitle">
                    <i class="fas fa-laptop-medical"></i> Telemedicine
                </h2>

                <div class="konsul-telemedicine-content">
                    <p>Telemedicine adalah layanan ...</p>

                    <div class="konsul-telemedicine-image">
                        <img src="<?php echo e(asset('/img/konsul.png')); ?>" alt="Konsultasi" class="konsul-telemedicine-img">
                    </div>

                    <h3 class="konsul-benefit-title">Manfaat Telemedicine:</h3>

                    <ul class="konsul-benefits-list">
                        <li>Konsultasi dirumah tanpa antri</li>
                        <li>Menghemat waktu dan biaya transportasi</li>
                        <li>Akses ke dokter lebih mudah</li>
                        <li>Efisiensi bagi Penyedia Layanan Kesehatan</li>
                        <li>Pemantauan Kesehatan Berkelanjutan</li>
                    </ul>
                </div>
            </section>
        </div>

        <!-- Kolom kanan -->
        <div class="konsul-right-column">

            <div class="konsul-doctors-section">
                <form method="GET" action="<?php echo e(route('konsultasi.index')); ?>" class="konsul-search-container" id="searchForm">
                    <input type="text" name="search" id="searchInput" value="<?php echo e($search); ?>" placeholder="Cari dokter berdasarkan nama, STR, SIP, atau email..." autocomplete="off">
                    <button type="submit"><i class="fas fa-search"></i> Cari</button>
                    <?php if($search): ?>
                        <a href="<?php echo e(route('konsultasi.index')); ?>" class="konsul-btn-clear" title="Clear search">
                            <i class="fas fa-times"></i>
                        </a>
                    <?php endif; ?>
                </form>

                <!-- Search Results Info -->
                <?php if($search): ?>
                    <div class="konsul-search-info">
                        <p>
                            <i class="fas fa-info-circle"></i> 
                            Menampilkan <strong><?php echo e($totalResults); ?></strong> hasil untuk "<strong><?php echo e($search); ?></strong>"
                            <?php if($totalResults == 0): ?>
                                <span style="color: #e74c3c;">- Tidak ada dokter yang ditemukan</span>
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>

                <div class="konsul-section-card">
                    <h2 class="konsul-sectiontitle">
                        <i class="fas fa-user-md"></i> Dokter Tersedia
                        <?php if(!$search): ?>
                            <span style="font-size: 14px; font-weight: normal; color: #666;">(<?php echo e($totalResults); ?> dokter)</span>
                        <?php endif; ?>
                    </h2>

                    <?php if($nakes->count() > 0): ?>
                    <div class="konsul-doctors-grid">

                        <?php $__currentLoopData = $nakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nakesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="konsul-doctor-card">

                            <div class="konsul-doctor-header">
                                <div class="konsul-doctor-avatar-sm" style="position: relative;">
                                    <?php if($nakesItem->foto_url): ?>
                                        <img src="<?php echo e($nakesItem->foto_url); ?>" alt="<?php echo e($nakesItem->nama); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/avatar/avatar-1.png')); ?>" alt="Default Avatar">
                                    <?php endif; ?>
                                    <?php if($nakesItem->user_id): ?>
                                        <span class="online-indicator" style="position: absolute; bottom: 5px; right: 5px; width: 12px; height: 12px; background: #4CAF50; border: 2px solid white; border-radius: 50%;" title="Tersedia untuk chat"></span>
                                    <?php endif; ?>
                                </div>

                                <div class="konsul-doctor-info-sm">
                                    <h3 class="konsul-doctor-name"><?php echo e($nakesItem->nama); ?></h3>
                                    <p class="konsul-doctor-specialty">
                                        <?php if($nakesItem->role === 'dokter_umum'): ?>
                                            Dokter Umum
                                        <?php elseif($nakesItem->role === 'admin'): ?>
                                            Admin Kesehatan
                                        <?php else: ?>
                                            <?php echo e(ucfirst($nakesItem->role)); ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>

                            <div class="konsul-doctor-info-card">
                                <!-- Kredensial -->
                                <?php if($nakesItem->str || $nakesItem->sip): ?>
                                <div class="konsul-info-item">
                                    <div class="konsul-info-icon"><i class="fas fa-certificate"></i></div>
                                    <div class="konsul-info-text">
                                        <h4>Kredensial</h4>
                                        <p>
                                            <?php if($nakesItem->str): ?>
                                                STR: <?php echo e($nakesItem->str); ?>

                                            <?php endif; ?>
                                            <?php if($nakesItem->str && $nakesItem->sip): ?>
                                                <br>
                                            <?php endif; ?>
                                            <?php if($nakesItem->sip): ?>
                                                SIP: <?php echo e($nakesItem->sip); ?>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Pengalaman -->
                                <?php if($nakesItem->tahun_mulai): ?>
                                <div class="konsul-info-item">
                                    <div class="konsul-info-icon"><i class="fas fa-briefcase"></i></div>
                                    <div class="konsul-info-text">
                                        <h4>Pengalaman</h4>
                                        <p><?php echo e($nakesItem->pengalaman); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Jadwal Praktik dengan Jam -->
                                <?php if($nakesItem->jadwal_shift && count($nakesItem->jadwal_shift) > 0): ?>
                                <div class="konsul-info-item">
                                    <div class="konsul-info-icon"><i class="fas fa-calendar-check"></i></div>
                                    <div class="konsul-info-text">
                                        <h4>Jadwal Praktik</h4>
                                        <div style="line-height: 1.8;">
                                            <?php
                                                $jadwalList = [];
                                                foreach($nakesItem->jadwal_shift as $jadwal) {
                                                    if (isset($jadwal['hari'])) {
                                                        $hari = $jadwal['hari'];
                                                        $jamMulai = $jadwal['jam_mulai'] ?? '';
                                                        $jamSelesai = $jadwal['jam_selesai'] ?? '';
                                                        
                                                        if ($jamMulai && $jamSelesai) {
                                                            $jadwalList[] = "$hari ($jamMulai - $jamSelesai)";
                                                        } else {
                                                            $jadwalList[] = $hari;
                                                        }
                                                    }
                                                }
                                            ?>
                                            <?php if(count($jadwalList) > 0): ?>
                                                <?php $__currentLoopData = $jadwalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div style="margin-bottom: 4px;">• <?php echo e($jadwal); ?></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <span class="text-muted">Jadwal belum diatur</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Role/Spesialisasi -->
                                <div class="konsul-info-item">
                                    <div class="konsul-info-icon"><i class="fas fa-user-md"></i></div>
                                    <div class="konsul-info-text">
                                        <h4>Spesialisasi</h4>
                                        <p>
                                            <?php if($nakesItem->role === 'dokter_umum'): ?>
                                                Dokter Umum
                                            <?php elseif($nakesItem->role === 'admin'): ?>
                                                Admin Kesehatan
                                            <?php else: ?>
                                                <?php echo e(ucfirst($nakesItem->role)); ?>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>

                                <div class="konsul-action-buttons">
                                    <?php if($nakesItem->user_id): ?>
                                        <a href="<?php echo e(route('chatify.user', ['id' => $nakesItem->user_id])); ?>" class="konsul-btnD konsul-btn-primary">
                                            <i class="fas fa-comments"></i> Chat Sekarang
                                        </a>
                                    <?php else: ?>
                                        <button class="konsul-btnD konsul-btn-primary" disabled title="Dokter belum terhubung ke sistem chat">
                                            <i class="fas fa-comments"></i> Chat Tidak Tersedia
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <?php if($nakes->hasPages()): ?>
                    <div class="konsul-pagination">
                        <?php echo e($nakes->links('pagination::bootstrap-4')); ?>

                    </div>
                    <?php endif; ?>

                    <?php else: ?>
                    <!-- No Results -->
                    <div class="konsul-no-results">
                        <div class="konsul-no-results-icon">
                            <i class="fas fa-user-md-slash fa-3x"></i>
                        </div>
                        <h3>Tidak Ada Dokter Ditemukan</h3>
                        <p>Maaf, tidak ada dokter yang sesuai dengan pencarian "<strong><?php echo e($search); ?></strong>"</p>
                        <a href="<?php echo e(route('konsultasi.index')); ?>" class="konsul-btnD konsul-btn-primary">
                            <i class="fas fa-arrow-left"></i> Lihat Semua Dokter
                        </a>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/konsultasi/konsultasiNakes.blade.php ENDPATH**/ ?>