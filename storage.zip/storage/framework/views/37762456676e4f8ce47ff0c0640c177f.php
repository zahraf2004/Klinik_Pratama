
<?php $__env->startSection('content'); ?>
<section class="hero-wrapper">
  <div class="hero-box">
    
    <!-- TEXT -->
    <div class="hero-text">
      <h1 class="hero-title">
        <span class="title-big">LANGKAH MUDAH</span><br>
        <span class="title-small">MENUJU KESEHATAN</span>
      </h1>
      <p>Cek kesehatan & konsultasi online dengan mudah</p>
      <a href="/login" class="btn-hero">Ayo Masuk Sekarang!</a>
    </div>

    <!-- IMAGE -->
    <div class="hero-image">
      <img src="/img/doktor.png" alt="Dokter">
    </div>

  </div>
</section>

<?php echo $__env->make('home.layanan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('home.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('home.doktor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('dashboard.review', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/home/homepage2.blade.php ENDPATH**/ ?>