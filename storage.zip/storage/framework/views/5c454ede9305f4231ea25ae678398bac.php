
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
    <h1>Dashboard</h1>
  </div>
  <?php echo $__env->make('dokter.partials.statistikDokter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('dokter.partials.bagian2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dokter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/dokter/DashboardDokter.blade.php ENDPATH**/ ?>