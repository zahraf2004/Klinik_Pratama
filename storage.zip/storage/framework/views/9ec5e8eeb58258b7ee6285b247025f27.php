
<?php $__env->startSection('content'); ?>
    <div class="pasien-container">
        <div class="pasien-main-content">
            <div class="pasien-content-area">
                <div class="main-column">
                    <div class="pasien-card">
                        <div class="pasien-card-header">
                            <div class="pasien-card-title">Profil Pasien</div>
                            <a href="javascript:void(0)" class="pasien-card-action" id="btnEditProfil">Edit Profil</a>
                        </div>
                        <div class="pasien-profile-info">
                            <div class="pasien-profile-avatar">
                                <?php if($profilPasien->foto): ?>
                                    <img src="<?php echo e(asset('storage/'.$profilPasien->foto)); ?>" alt="Foto Profil">
                                <?php else: ?>
                                    <?php echo e(substr($user->name, 0, 2)); ?>

                                <?php endif; ?>
                            </div>

                            <div class="pasien-profile-details">
                                <div class="pasien-profile-name"><?php echo e($user->name); ?></div>
                                <div class="pasien-profile-id">ID Pasien: P-<?php echo e($user->id); ?></div>

                                <div class="pasien-info-grid">
                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">Tanggal Lahir</div>
                                        <div class="pasien-info-value">
                                            <?php echo e($profilPasien->tanggal_lahir ? $profilPasien->tanggal_lahir->format('d F Y') : '-'); ?>

                                        </div>
                                    </div>

                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">Jenis Kelamin</div>
                                        <div class="pasien-info-value"><?php echo e($profilPasien->jenis_kelamin ?? '-'); ?></div>
                                    </div>

                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">No. Telepon</div>
                                        <div class="pasien-info-value"><?php echo e($profilPasien->no_hp ?? '-'); ?></div>
                                    </div>

                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">Email</div>
                                        <div class="pasien-info-value"><?php echo e($user->email); ?></div>
                                    </div>

                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">Alamat</div>
                                        <div class="pasien-info-value"><?php echo e($profilPasien->alamat ?? '-'); ?></div>
                                    </div>

                                    <div class="pasien-info-item">
                                        <div class="pasien-info-label">Golongan Darah</div>
                                        <div class="pasien-info-value"><?php echo e($profilPasien->golongan_darah ?? '-'); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="pasien-card">
                        <div class="pasien-card-header">
                            <div class="pasien-card-title">Janji Temu Mendatang</div>
                            <a href="#" class="pasien-card-action">Lihat Semua</a>
                        </div>

                        <div class="pasien-appointment-list">
                            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="pasien-appointment-item">
                                    <div class="pasien-appointment-details">
                                        <!-- Nama pasien (ambil dari kolom nama_pasien, fallback ke user jika kosong) -->
                                        <div class="pasien-appointment-doctor">
                                            <?php echo e($appt->nama_pasien ?? $user->name); ?>

                                        </div>

                                        <!-- Tanggal (pakai field tanggal_indo yang sudah diset di controller) + jam -->
                                        <div class="pasien-appointment-date">
                                            <?php echo e($appt->tanggal_indo); ?> - <?php echo e(\Carbon\Carbon::parse($appt->jam)->format('H:i')); ?> WIB
                                        </div>
                                    </div>

                                    <!-- Status -->
                                    <div class="pasien-appointment-status <?php echo e($appt->status == 'dikonfirmasi' ? 'pasien-status-confirmed' : 'pasien-status-pending'); ?>">
                                        <?php echo e(ucfirst($appt->status)); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500 px-4 py-2">Belum ada janji temu.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="pasien-card">
                        <div class="pasien-card-header">
                            <div class="pasien-card-title">Status Chat & Pembayaran</div>
                        </div>

                        <div class="payment-status-simple">
                            <?php
                                $recentPayments = Auth::user()->transactions()
                                    ->where('transaction_status', 'settlement')
                                    ->where('description', 'like', '%Berlangganan%')
                                    ->latest()
                                    ->take(3)
                                    ->get();
                                
                                $hasActiveSubscription = Auth::user()->hasActiveSubscription();
                                $remainingTokens = Auth::user()->getRemainingSessionTokens();
                            ?>

                            
                            <div class="chat-status-info">
                                <?php if($hasActiveSubscription): ?>
                                    <div class="status-item premium">
                                        <i class="fas fa-crown"></i>
                                        <span><strong>Premium Active</strong> - Chat Unlimited</span>
                                    </div>
                                <?php else: ?>
                                    <div class="status-item free">
                                        <i class="fas fa-comments"></i>
                                        <span>Session Token: <strong><?php echo e($remainingTokens); ?>/3</strong> tersisa</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            
                            <?php if($recentPayments->count() > 0): ?>
                                <div class="payment-details">
                                    <h6>Detail Pembayaran:</h6>
                                    <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="payment-detail-item">
                                            <div class="payment-header">
                                                <div class="payment-desc"><?php echo e($payment->description); ?></div>
                                                <div class="payment-status">
                                                    <?php if($payment->transaction_status === 'settlement'): ?>
                                                        <span class="badge-success">Berhasil</span>
                                                    <?php elseif($payment->transaction_status === 'pending'): ?>
                                                        <span class="badge-pending">Pending</span>
                                                    <?php else: ?>
                                                        <span class="badge-failed"><?php echo e(ucfirst($payment->transaction_status)); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="payment-info-grid">
                                                <div class="info-item">
                                                    <span class="label">Order ID:</span>
                                                    <span class="value"><?php echo e($payment->order_id); ?></span>
                                                </div>
                                                <div class="info-item">
                                                    <span class="label">Jumlah:</span>
                                                    <span class="value amount">Rp <?php echo e(number_format($payment->gross_amount, 0, ',', '.')); ?></span>
                                                </div>
                                                <div class="info-item">
                                                    <span class="label">Tanggal:</span>
                                                    <span class="value"><?php echo e($payment->created_at->format('d/m/Y H:i')); ?></span>
                                                </div>
                                                <?php if($payment->payment_type): ?>
                                                <div class="info-item">
                                                    <span class="label">Metode:</span>
                                                    <span class="value"><?php echo e(ucfirst($payment->payment_type)); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php if($payment->transaction_id): ?>
                                                <div class="info-item">
                                                    <span class="label">Transaction ID:</span>
                                                    <span class="value"><?php echo e($payment->transaction_id); ?></span>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            
                            <?php if(app()->environment('local') && $recentPayments->count() > 0): ?>
                                <?php $latestPayment = $recentPayments->first(); ?>
                                <?php if($latestPayment->transaction_status === 'pending'): ?>
                                    <div style="margin-top: 10px; text-align: center;">
                                        <a href="/update-transaction-status/<?php echo e($latestPayment->order_id); ?>" 
                                           style="font-size: 0.7rem; color: #6c757d; text-decoration: none;"
                                           title="Development: Update transaction status">
                                            [Dev: Update Status]
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                        </div>
                    </div>

                </div>

                <div class="side-column">
                    <div class="pasien-card">
                        <div class="pasien-card-header">
                            <div class="pasien-card-title">Statistik Kesehatan</div>
                        </div>

                        <div class="pasien-profile-stats">
                            <div class="pasien-stat-item">
                                <div class="pasien-stat-value"><?php echo e($profilPasien->berat_badan ?? '-'); ?></div>
                                <div class="pasien-stat-label">KG</div>
                            </div>

                            <div class="pasien-stat-item">
                                <div class="pasien-stat-value"><?php echo e($profilPasien->tinggi_badan ?? '-'); ?></div>
                                <div class="pasien-stat-label">CM</div>
                            </div>

                            <div class="pasien-stat-item">
                                <div class="pasien-stat-value"><?php echo e($profilPasien->bmi ?? '-'); ?></div>
                                <div class="pasien-stat-label">BMI</div>
                            </div>
                        </div>
                    </div>

                    <div class="pasien-card">
                        <div class="pasien-card-header">
                            <div class="pasien-card-title">Aksi Cepat</div>
                        </div>

                        <div class="pasien-quick-actions">
                            <a href="/Janji-Berobat" class="pasien-action-btn">
                                <i class="fas fa-calendar-plus pasien-action-icon"></i>
                                <div class="pasien-action-label">Buat Janji</div>
                            </a>

                            <a href="/chatify" class="pasien-action-btn">
                                <i class="fa-solid fa-headset pasien-action-icon"></i>
                                <div class="pasien-action-label">Chat Online</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Popup -->
    <?php echo $__env->make('profilPasien._modalprofil', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(auth()->guard()->check()): ?>
    <script>
        // Define global variables untuk digunakan di file external
        window.profilUpdateUrl = "<?php echo e(route('pasien.profil.update')); ?>";
        window.csrfToken = "<?php echo e(csrf_token()); ?>";
    </script>
    <script src="<?php echo e(asset('js/profil_pasien.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/profilPasien/profil.blade.php ENDPATH**/ ?>