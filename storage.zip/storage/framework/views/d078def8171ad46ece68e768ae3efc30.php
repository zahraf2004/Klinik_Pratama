<div class="row">
    <div class="col-lg-8 col-md-12 col-12 col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4>Statistik Janji Berobat Selesai</h4>
        </div>
        <div class="card-body">
          <canvas id="janjiChart" height="120"></canvas>
        </div>
      </div>
    </div>


    <!-- Janji Berobat Terbaru -->
    <div class="col-lg-4 col-md-12 col-12 col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4>Janji Berobat Terbaru</h4>
        </div>
        <div class="card-body">
          <ul class="list-unstyled p-0 list-unstyled-border">
            <?php $__empty_1 = true; $__currentLoopData = $janjiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $janji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="media">
              <img class="mr-3 rounded-circle" width="50" src="assets/img/avatar/avatar-1.png" alt="avatar">
              <div class="media-body">
                <div class="float-right text-primary"><?php echo e($janji->created_at->diffForHumans()); ?></div>
                <div class="media-title"><?php echo e($janji->nama); ?></div>
                <span class="text-small text-muted">Keluhan: <?php echo e($janji->keluhan); ?></span>
              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="media">
              <div class="media-body text-center">
                <div class="text-muted">Belum ada janji berobat</div>
              </div>
            </li>
            <?php endif; ?>
          </ul>

          <div class="text-center pt-1 pb-1">
            <a href="<?php echo e(route('appointment.admin')); ?>" class="btn btn-primary btn-lg btn-round">
              Lihat Semua
            </a>
          </div>
        </div>
      </div>
    </div>
</div>
<?php /**PATH E:\ProjekKlinik\resources\views/adminDashboard/partials/baris2.blade.php ENDPATH**/ ?>