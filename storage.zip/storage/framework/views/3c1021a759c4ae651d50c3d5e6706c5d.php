<section class="product-section">
    <h2 style="margin-top:75px;">Obat & Suplemen Kesehatan</h2>

    <!-- Kategori --> 
     <div class="categories"> 
        <button class="active">Obat Bebas</button> 
        <button>Obat Bebas terbatas</button> <button>obat Keras</button> 
        <button>Jamu</button> 
        <a href="<?php echo e(route('obat.all')); ?>" class="see-all">Lihat Semua Kategori Obat</a> </div>

    <!-- Grid Produk -->
    <div class="product-grid">
        <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-card">
                <img src="<?php echo e(asset('storage/'.$item->foto)); ?>" alt="<?php echo e($item->nama_obat); ?>">
                <h3><?php echo e($item->nama_obat); ?></h3>
                <p class="unit"><?php echo e($item->bentuk); ?></p>
                <a href="<?php echo e(route('obat.show', $item->id)); ?>">
                    <button>Lihat Informasi Obat</button>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH E:\ProjekKlinik\resources\views/dashboard/obat.blade.php ENDPATH**/ ?>