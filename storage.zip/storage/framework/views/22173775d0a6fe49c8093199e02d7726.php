<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
    <h1>Dashboard</h1>
  </div>
  
  <?php echo $__env->make('adminDashboard.partials.statistic', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('adminDashboard.partials.baris2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('adminDashboard.partials.baris3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById("janjiChart").getContext('2d');
    
    // Data dari controller
    var chartLabels = <?php echo json_encode($chartData['labels'], 15, 512) ?>;
    var chartData = <?php echo json_encode($chartData['data'], 15, 512) ?>;
    
    var janjiChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: chartLabels,
        datasets: [{
          label: 'Janji Selesai',
          data: chartData,
          backgroundColor: '#3498DB',
          borderColor: '#3498DB',
          borderWidth: 2,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            labels: {
              color: '#252525'
            }
          },
          title: {
            display: true,
            text: 'Statistik Janji Berobat Selesai (12 Bulan Terakhir)',
            color: '#252525'
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              callback: function(value) {
                return Number.isInteger(value) ? value : '';
              }
            }
          },
          x: {
            ticks: {
              maxRotation: 45,
              minRotation: 45
            }
          }
        }
      }
    });
  });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\ProjekKlinik\resources\views/adminDashboard/DashboardAdmin.blade.php ENDPATH**/ ?>